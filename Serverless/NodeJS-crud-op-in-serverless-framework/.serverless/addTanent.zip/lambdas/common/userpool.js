const AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool;
const AWS = require('aws-sdk');
const request = require('request');
const jwkToPem = require('jwk-to-pem');
const jwt = require('jsonwebtoken');
global.fetch = require('node-fetch');

const cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

const userPool = {

    async createUserPooll(poolName){

        let params = {
            PoolName: poolName,
            AutoVerifiedAttributes: [
                "email"
            ],
            AdminCreateUserConfig: {
                AllowAdminCreateUserOnly: false,
                InviteMessageTemplate: {
                    EmailMessage: 'Your username is {username} and temporary password is {####}',
                    EmailSubject: 'Your temporary password',
                    SMSMessage: 'Your username is {username} and temporary password is {####}'
                },
                UnusedAccountValidityDays: '365'
            },
            EmailConfiguration: {
                EmailSendingAccount: "DEVELOPER",
                SourceArn: "arn:aws:ses:us-east-1:020046395185:identity/aamirshehzad8822@gmail.com"
            },
            EmailVerificationMessage: 'Your verification code is {####}',
            EmailVerificationSubject: 'Your temporary password',
            VerificationMessageTemplate: {
                DefaultEmailOption: 'CONFIRM_WITH_CODE',
                EmailMessage: 
                `Code: {####}`,
                EmailSubject: 'Welcome aboard!!.',
            },
            "Schema": [
                {
                    "AttributeDataType": "String",
                    "Mutable": true,
                    "Name": "cuid",
                },
                {
                    "AttributeDataType": "String",
                    "Mutable": true,
                    "Name": "tenantid",
                },
                {
                    "AttributeDataType": "String",
                    "Mutable": true,
                    "Name": "role",
                }
            ]

        };


        const resp = await cognitoidentityserviceprovider.createUserPool(params).promise();

        if(!resp)
            throw Error("error while creating userpool")
            
        return resp
            
    },

    async createUserPoolClientt(poolid) {

        let params = {
            "ClientName": "newclient",

            "UserPoolId": poolid,
            "ExplicitAuthFlows": [
                "ALLOW_CUSTOM_AUTH",
                "ALLOW_USER_PASSWORD_AUTH",
                "ALLOW_USER_SRP_AUTH",
                "ALLOW_REFRESH_TOKEN_AUTH",
            ],
            "GenerateSecret": false,
            "RefreshTokenValidity": 30,
        };
        console.log(`params for poolclient---- ${params}`);
        let clientresp = await cognitoidentityserviceprovider.createUserPoolClient(params).promise();
        console.log(clientresp);
        return (clientresp);
    },


    async createUserPoolDomainn(domainName, userPoolId) {

        console.log("Started User pool domain creation...");
        try {
            let params = {
                Domain: domainName,
                UserPoolId: userPoolId 
            };
            return await cognitoidentityserviceprovider.createUserPoolDomain(params).promise();
        }
        catch (cupE) {
            console.log(cupE);
            reject(cupE);
        }
    },

    async createTenantUser(clientId, userPoolId, customerBody, cuid, role) {
        console.log("Started creating tenant user");
        try {
            const uuid = cuid;
            const password = "sakdljlka" + "u!1";
            let params = {
                ClientId: clientId,
                Username: customerBody.email,
                Password: password,
                UserAttributes: [
                    {
                        Name: 'email',
                        Value: customerBody.email
                    },
                    {
                        Name: 'phone_number', /* required */
                        Value: customerBody.phone_number
                    },
                    {
                        Name: 'custom:cuid', /* required */
                        Value: uuid
                    },
                    {
                        Name: 'custom:tenantid', /* required */
                        Value: customerBody.tenant_id
                    },
                    {
                        Name: 'custom:role', /* required */
                        Value: role
                    }
                ]
            }
            let signupresp = await cognitoidentityserviceprovider.signUp(params).promise();

            return signupresp;
        }
        catch (cupE) {
            console.log(cupE);
        }
        return null;
    }

};

module.exports = userPool;