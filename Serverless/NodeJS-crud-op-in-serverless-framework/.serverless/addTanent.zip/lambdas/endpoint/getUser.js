const Responses = require('../common/API_Responses')


const data = {
    1234: {'name': 'Aamir Shehzad', 'job': 'DevOps Engineer'},
    1124: {'name': 'Hamza Jamal', 'job': 'UI/UX Designer'},
    1256: {'name': 'Tuba Gul', 'job': 'UI/UX Designer'}
}

exports.handler_api = async event => {
    

    console.log('event',event);


    if(!event.pathParameters || !event.pathParameters.ID){
       return Responses._400({message: 'Missing the ID from the path'})
    }
    
       
    let id = event.pathParameters.ID;

    if(data[id]){        
        return Responses._200(data[id])
    }

    return Responses._400({message: 'no ID in data'})



}
