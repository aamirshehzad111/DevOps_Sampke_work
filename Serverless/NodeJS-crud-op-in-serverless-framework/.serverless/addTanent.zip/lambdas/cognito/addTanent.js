const Responses = require('../common/API_Responses')
const userPool = require('../common/userpool')


exports.handler_api = async event => {
     
    console.log('event',event);
    
    if(!event.pathParameters || !event.pathParameters.ID)
        return Responses._400({message: 'Missing the ID from the path'})
    
    let ID = event.pathParameters.ID;    
    const user = JSON.parse(event.body)
    user.cuid =  ID      
    

    const newPool = await  userPool.createUserPooll('aamir-test').catch(err => {
        console.log("Error in creating pool",err)
        return null
    })

    if(!newPool){
       return Responses._400({message: 'Failed to get pool data : '+newPool})
    }
    
    return Responses._200({newPool})
 
}